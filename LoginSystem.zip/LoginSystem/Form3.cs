﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSystem
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (txt_user.Text != "" || txt_pass.Text != "")
            {
                int CURRENT_INDEX = Form1.index;
                Form1.Username[CURRENT_INDEX] = txt_user.Text.ToString();
                Form1.Password[CURRENT_INDEX] = txt_pass.Text.ToString();
                MessageBox.Show("Profile Successfully Updated, Logout to see changes.", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Please fill the fields", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
