﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace LoginSystem
{
    public partial class Form2 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }

        }


       

        internal void LoginData(String Username, String Password, String Usertype)
        {
            label1.Text = "Welcome, " + Username + "!";
            if (Usertype == "admin")
            {
                button1.Enabled = true;
                button2.Enabled = true;
                label2.Text = "You are : " + Usertype.ToUpper() + ". \nYou can view your detail\nYou can Edit your detail";
            }else
            {
                label2.Text = "You are : " + Usertype.ToUpper() + ". \nYou can view your detail\nYou cannot Edit your detail";
                button1.Text = "View";
                button2.Enabled = false;
                button1.Enabled = true;

            }
        }

       
        private void button1_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("Hello");
             MessageBox.Show("Your Name: " + Form1.Username[Form1.index] + "\nYour Password: " + Form1.Password[Form1.index] + "\nYou are " + Form1.UserType[Form1.index], "My Detail", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public static bool is_Login = true;
        public void btn_close_Click(object sender, EventArgs e)
        {
            DialogResult confirm = MessageBox.Show("Are You sure you want to logout?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (confirm == DialogResult.Yes)
            {
                this.Hide();
                Form1 loginpage = new Form1();
                loginpage.Closed += (s, args) => this.Close();
                is_Login = false;
                loginpage.Show();
            }
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 editform = new Form3();
            editform.Show();
        }
    }
}
