﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace LoginSystem
{
    public partial class Form1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public Form1()
        {
            InitializeComponent();
        }
     
        private void Form1_MouseDown_1(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void btn_close_MouseHover(object sender, EventArgs e)
        {
            btn_close.ForeColor = Color.DarkRed;            
        }

        private void btn_close_MouseLeave(object sender, EventArgs e)
        {
          
            btn_close.ForeColor = Color.DarkGray;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (txt_user.Text == "Username")
            {
                txt_user.Text = "";
            }
           
        }

   
        private void txt_Password_MouseDown(object sender, MouseEventArgs e)
        {
            if (txt_Password.Text == "Password")
            {
                txt_Password.Text = "";
            }
        }

       
        private void txt_user_Leave(object sender, EventArgs e)
        {

            if (txt_user.Text == "")
            {
                txt_user.Text = "Username";
            }
        }

        private void txt_Password_Leave(object sender, EventArgs e)
        {
            if (txt_Password.Text == "")
            {
                txt_Password.PasswordChar = '\0';
                txt_Password.Text = "Password";
            }
        }

        private void txt_Password_TextChanged(object sender, EventArgs e)
        {
            txt_Password.PasswordChar = '•';
        }



        // Login Criteria 
       // public static String[] Username = { "Admin", "Hanif" };
        public static List<string> Username = new List<string>();
        public static List<string> Password = new List<string>();
        public static List<string> UserType = new List<string>();
        public static int index = 0;

        
        private void btn_login_Click(object sender, EventArgs e)
        {
            //pre defined values
            Username.Insert(0,"admin"); Password.Insert(0,"admin"); UserType.Insert(0, "Admin");
            Username.Insert(1, "hanif"); Password.Insert(1, "hanif"); UserType.Insert(1, "Manager");

            bool log_sts = false;
            String User = txt_user.Text.ToString();
            String pass = txt_Password.Text;
            
            for (int i = 0; i < Username.Count; i++)
            {
                if (Username[i].ToLower() == User.ToLower() && Password[i] == pass)
                {
                    this.Hide();
                    index = i;
                    Form2 frm_success = new Form2();
                    frm_success.LoginData(Username[i], Password[i], UserType[i]);
                    frm_success.Closed += (s, args) => this.Close();
                    frm_success.Show();
                    log_sts = true;
                    break;
                }

            }
            if (log_sts == false)
            {
                MessageBox.Show("Could not login!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            if (Form2.is_Login == false)
            {
                label2.Visible = true;

            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btn_login_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 frm_reg = new Form4();
            frm_reg.Closed += (s, args) => this.Close();
            frm_reg.Show();
        }
    }
}
