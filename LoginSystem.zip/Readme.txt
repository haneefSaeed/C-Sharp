Hello, 

Thank you for downloading The Basic login and register system developed in C#.

If you have any problem or inquiry, contact me, I'll be glad to help.
hanif.sayeedi@gmail.com

Check out my GitHub for more cool things in future :)
https://github.com/haneefSaeed/


Enjoy!
Hanif